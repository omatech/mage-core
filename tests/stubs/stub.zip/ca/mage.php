<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Mage
    |--------------------------------------------------------------------------
    */

    'fionamoore' => 'mage.fionamoore',
    'santinaschowalterjr.' => 'mage.santinaschowalterjr.',
    'pearlinemuller' => 'mage.pearlinemuller',
];
